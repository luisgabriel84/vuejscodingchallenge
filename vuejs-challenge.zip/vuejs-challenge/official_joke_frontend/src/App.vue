<script setup>
import { ref, computed, onMounted } from "vue";

import JokeCard from "./components/JokeCard.vue";
import JokeNavigation from "./components/JokeNavigation.vue";
import JokeHeader from "./components/JokeHeader.vue";
import JokePagination from "./components/JokePagination.vue";
import JokeSpinner from "./components/JokeSpinner.vue";
import JokeNumberSelector from "./components/JokeNumberSelector.vue";

const jokeTypes = ref([]);
const jokes = ref([]);
const loading = ref(true);

// pagination
const postXpage = 10;
const start = ref(0);
const end = ref(postXpage);
const maxLength = computed(() => jokes.value.length);

const resetPagination = () => {
  start.value = 0;
  end.value = postXpage;
};

//functions
const getJokeTypes = async () => {
  try {
    const jokeTypesRes = await fetch("http://localhost:3005/types");
    jokeTypes.value = await jokeTypesRes.json();
  } catch (error) {
    console.log(error);
  }
};
const getRandomJoke = async () => {
  loading.value = true;
  resetPagination();
  try {
    const jokesRes = await fetch("http://localhost:3005/jokes/random");
    jokes.value = await jokesRes.json();
  } catch (error) {
    console.log(error);
  } finally {
    loading.value = false;
  }
};

const getRandomTen = async () => {
  loading.value = true;
  resetPagination();
  try {
    const jokesRes = await fetch("http://localhost:3005/random_ten");
    jokes.value = await jokesRes.json();
  } catch (error) {
    console.log(error);
  } finally {
    loading.value = false;
  }
};

const getJokesByType = async (joketype) => {
  loading.value = true;
  resetPagination();
  try {
    const jokesRes = await fetch(`http://localhost:3005/jokes/${joketype}/ten`);
    jokes.value = await jokesRes.json();
  } catch (error) {
    console.log(error);
  } finally {
    loading.value = false;
  }
};

const getJokesRandomNumber = async (jokeNumber) => {
  loading.value = true;
  resetPagination();
  try {
    const jokesRes = await fetch(`http://localhost:3005/jokes/random/${jokeNumber}`);
    jokes.value = await jokesRes.json();
  } catch (error) {
    console.log(error);
  } finally {
    loading.value = false;
  }
};

const next = () => {
  start.value = start.value + postXpage;
  end.value = end.value + postXpage;
};

const prev = () => {
  start.value += -postXpage;
  end.value += -postXpage;
};
onMounted(() => {
  getJokeTypes();
  getRandomJoke();
});
</script>
<template>
  <div class="container min-vh-100">
    <JokeHeader />
    <div class="row align-items-top justify-content-center mt-5">
      <div class="col-md-3 col-sm-12">
        <JokeNavigation
          :joketypes="jokeTypes"
          @getRandomJoke="getRandomJoke"
          @getRandomTen="getRandomTen"
          @getJokesByType="getJokesByType"
        />

        <JokeNumberSelector @getJokesRandomNumber="getJokesRandomNumber" />
      </div>
      <div class="col-md-9 col-sm-12">
        <JokeSpinner v-if="loading" />
        <div
          class="row"
          v-else
        >
          <div class="row">
            <div
              class="col-sm-12 mb-2 text-center"
              v-if="Array.isArray(jokes)"
            >
              Viewing {{ jokes.length }} jokes
            </div>
          </div>
          <JokeCard
            :jokeId="jokes.id"
            :jokeSetup="jokes.setup"
            :jokePunchline="jokes.punchline"
            :jokeType="jokes.type"
            v-if="!Array.isArray(jokes)"
            :columnWidth="12"
          />
          <JokeCard
            v-else
            v-for="jokeItem in jokes.slice(start, end)"
            :key="jokeItem.id"
            :jokeId="jokeItem.id"
            :jokeSetup="jokeItem.setup"
            :jokePunchline="jokeItem.punchline"
            :jokeType="jokeItem.type"
            :columnWidth="6"
          />

          <div
            class="justify-content-center align-items-top"
            v-if="Array.isArray(jokes)"
          >
            <JokePagination
              @next="next"
              @prev="prev"
              :start="start"
              :end="end"
              :maxLength="maxLength"
              v-if="jokes.length > postXpage"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss">
@import "@/assets/scss/main.scss";
</style>
