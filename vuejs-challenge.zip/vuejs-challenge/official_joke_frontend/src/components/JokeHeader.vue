<script setup></script>
<template>
  <header class="mt-5">
    <h1 class="text-white fs-1 fw-bold">Official Joke Application</h1>
    <p class="text-white fs-4">Read some jokes laugh a little</p>
  </header>
</template>
<style lang="scss">
header {
  h1 {
    border-bottom: 2px solid #fff;
  }
}
</style>
