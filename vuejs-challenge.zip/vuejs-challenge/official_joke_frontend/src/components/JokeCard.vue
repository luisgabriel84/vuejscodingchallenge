<script setup>
import { ref, computed } from "vue";
const props = defineProps({
  jokeId: Number,
  jokeSetup: String,
  jokePunchline: String,
  jokeType: String,
  columnWidth: String,
});
</script>

<template>
  <div
    :class="`col-${columnWidth}`"
    class="mb-4 align-items-stretch"
  >
    <div class="card shadow-lg h-100">
      <div class="card-body">
        <h4 clas="fw-bold">{{ jokeSetup }}</h4>
        <div class="card-text">
          {{ jokePunchline }}
        </div>
      </div>
      <div class="card-footer text-muted fs-6">{{ jokeType }}</div>
    </div>
  </div>
</template>
