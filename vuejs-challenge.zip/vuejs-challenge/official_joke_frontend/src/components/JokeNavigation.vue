<script setup>
const props = defineProps({
  joketypes: Array,
});

defineEmits(["getRandomJoke", "getRandomTen", "getJokesByType"]);
</script>

<template>
  <div
    class="btn-group-vertical d-block btn-group-lg"
    role="group"
    aria-label="select options to view some jokes"
  >
    <button
      type="button"
      class="btn btn-outline-secondary"
      @click="$emit('getRandomJoke')"
    >
      Get a random joke
    </button>
    <button
      type="button"
      class="btn btn-outline-secondary"
      @click="$emit('getRandomTen')"
    >
      Random 10 Jokes
    </button>

    <div
      class="btn-group btn-group-lg mb-5"
      role="group"
    >
      <button
        id="btnGroupDrop1"
        type="button"
        class="btn dropdown-toggle btn-outline-secondary btn-group-lg"
        data-bs-toggle="dropdown"
        aria-expanded="false"
      >
        Jokes by type
      </button>
      <ul
        class="dropdown-menu btn-group-lg w-100"
        aria-labelledby="btnGroupDrop1"
      >
        <li
          v-for="(joketype, index) in joketypes"
          :key="index"
        >
          <a
            class="dropdown-item btn-lg"
            @click="$emit('getJokesByType', joketype)"
            >{{ joketype }}</a
          >
        </li>
      </ul>
    </div>
  </div>
</template>
<style lang="scss">
@import "@/assets/scss/main.scss";
.btn {
  background-color: #fff !important;
  color: #000 !important;
}
.btn:hover {
  color: #000 !important;
  background-color: #f9efa4 !important;
}
.dropdown-item:hover {
  background-color: #f9efa4 !important;
}
.dropdown-item {
  text-transform: capitalize;
  cursor: pointer;
}
</style>
