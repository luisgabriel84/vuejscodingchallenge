<script setup>
import { ref } from "vue";
const maxNumberOfJokes = ref(100);

const emits = defineEmits(["getJokesRandomNumber"]);
const logSelectedOption = (event) => {
  emits("getJokesRandomNumber", event.target.value);
};
</script>
<template>
  <select
    class="form-select mb-5"
    aria-label="Select more jokes"
    @change="logSelectedOption($event)"
  >
    <option selected>How many jokes do you want to see?</option>
    <option
      v-for="index in maxNumberOfJokes"
      :key="index"
      :value="index"
    >
      {{ index }}
    </option>
  </select>
</template>
