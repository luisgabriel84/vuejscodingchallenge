<script setup></script>
<template>
  <div class="text-center">
    <div
      class="spinner-border"
      role="status"
    ></div>
    <p class="text-center mt-2">Loading jokes..</p>
  </div>
</template>
