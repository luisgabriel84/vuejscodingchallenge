<script setup>
const props = defineProps({
  start: Number,
  end: Number,
  maxLength: Number,
});
defineEmits(["prev", "next"]);
</script>
<template>
  <nav aria-label="pagination">
    <ul class="pagination justify-content-center">
      <li
        class="page-item"
        :class="start <= 0 ? 'disabled' : ''"
      >
        <a
          class="page-link"
          tabindex="-1"
          :aria-disabled="start <= 0 ? 'disabled' : ''"
          @click="$emit('prev')"
          >Previous
        </a>
      </li>

      <li class="page-item">
        <a
          class="page-link"
          :class="end >= maxLength ? 'disabled' : ''"
          :aria-disabled="end >= maxLength ? 'disabled' : ''"
          @click="$emit('next')"
          >Next
        </a>
      </li>
    </ul>
  </nav>
</template>
<style>
.page-link {
  cursor: pointer;
}
</style>
